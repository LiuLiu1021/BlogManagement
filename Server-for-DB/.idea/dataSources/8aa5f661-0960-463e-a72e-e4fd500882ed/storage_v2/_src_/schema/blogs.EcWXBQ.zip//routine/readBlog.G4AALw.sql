create
    definer = test@`%` procedure readBlog(IN blog_id int, IN user_id int)
BEGIN
   DECLARE credit int;
   declare DeDreputation int;
   declare deneed_credit int;
   SELECT @credit=credit, @reputation=reputation
   FROM Blog_User
   WHERE user_id=@user_id;         
   SELECT @need_credit=need_credit
   FROM Blog
   WHERE blog_id=@blog_id;

   IF @reputation=4  THEN 
      SET @need_credit=@need_credit*1.05;
   END IF;
   IF @reputation=3  THEN
      SET @need_credit=@need_credit*1.1;
   END IF;
   IF @reputation=2  THEN         
      SET @need_credit=@need_credit*1.2;
   END IF;
   IF @reputation=1 THEN
      SELECT -9999;
    END IF;
   IF @credit<@need_credit  THEN
      SELECT @credit-@need_credit;
   END IF;
   
   UPDATE Blog_User
   SET credit=credit-@need_credit
   WHERE user_id=@user_id;

   UPDATE Blog_User
   SET credit=credit+@need_credit
   WHERE user_id=(SELECT user_id
               FROM Blog
               WHERE blog_id=@blog_id);

   INSERT INTO History VALUES(@user_id,@blog_id,GETDATE());

   UPDATE Blog
   SET browse_number=browse_number+1
   WHERE blog_id=@blog_id;#                  --给博客增加浏览量

   SELECT @need_credit;#        --返回扣除的积分
END;

